﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SpellCalculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SpellCalculatorVM spellCalculatorVM;
        public MainWindow()
        {
            InitializeComponent();
            spellCalculatorVM = new SpellCalculatorVM();
            DataContext = spellCalculatorVM;
            MessageBox.Show(spellCalculatorVM.Spells.Count().ToString());
        }

        private void ComboBox_ArcanaChanged(object sender, SelectionChangedEventArgs e)
        {
            spellCalculatorVM.GetAvailableSpells();
        }

        private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (spellCalculatorVM != null)
            {
                spellCalculatorVM.GetAvailableSpells();
                spellCalculatorVM.GetDicePool();
            }
        }

        private void Slider_PotencyChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (spellCalculatorVM != null)
            {
                spellCalculatorVM.GetDicePool();
            }
        }

        private void cmbSpell_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            spellCalculatorVM.GetSpellStats();
        }

        #region Reach

        void CastingTime(object sender, RoutedEventArgs e)
        {
            RadioButton li = (sender as RadioButton);
            if (spellCalculatorVM != null)
            {
                spellCalculatorVM.GetCastingTime(li.Content.ToString());
            }
        }

        void Range(object sender, RoutedEventArgs e)
        {
            RadioButton li = (sender as RadioButton);
            if (spellCalculatorVM != null)
            {
                spellCalculatorVM.GetRange(li.Content.ToString());
            }
        }

        void Potency(object sender, RoutedEventArgs e)
        {
            RadioButton li = (sender as RadioButton);
            if (spellCalculatorVM != null)
            {
                spellCalculatorVM.GetPotency(li.Content.ToString());
            }
        }

        #endregion

        #region Dice Pool

        private void gnosisValue_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (spellCalculatorVM != null)
            {
                spellCalculatorVM.GetDicePool();
            }
            
        } 

        #endregion
    }
}
