﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace SpellCalculator
{
    class SpellCalculatorVM : INotifyPropertyChanged
    {
        public SpellCalculatorVM()
        {
            Spell spell = new Spell();
            Spells = spell.CreateSpellList();

            getArcana();
        }
        
        #region Properties
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        #region Spells

        private ObservableCollection<Spell> spells = new ObservableCollection<Spell>();
        public ObservableCollection<Spell> Spells
        {
            get { return spells; }
            set
            {
                spells = value;
                OnPropertyChanged("Spells");
            }
        }

        private ObservableCollection<Spell> availableSpells = new ObservableCollection<Spell>();
        public ObservableCollection<Spell> AvailableSpells
        {
            get { return availableSpells; }
            set
            {
                spells = value;
                OnPropertyChanged("AvailableSpells");
            }
        }

        private Spell selectedSpell;
        public Spell SelectedSpell
        {
            get { return selectedSpell; }
            set
            {
                selectedSpell = value;
                OnPropertyChanged("SelectedSpell");
            }
        }

        #endregion

        #region Arcana

        private ObservableCollection<string> arcana = new ObservableCollection<string>();
        public ObservableCollection<string> Arcana
        {
            get { return arcana; }
            set
            {
                arcana = value;
                OnPropertyChanged("Arcana");
            }
        }

        private int gnosis = 1;
        public int Gnosis
        {
            get { return gnosis; }
            set
            {
                gnosis = value;
                OnPropertyChanged("Gnosis");
            }
        }


        private string primaryArcana;
        public string PrimaryArcana
        {
            get { return primaryArcana; }
            set
            {
                primaryArcana = value;
                OnPropertyChanged("PrimaryArcana");
            }
        }

        private int primaryRating;
        public int PrimaryRating
        {
            get { return primaryRating; }
            set
            {
                primaryRating = value;
                OnPropertyChanged("PrimaryRating");
            }
        }

        private string secondaryArcana;
        public string SecondaryArcana
        {
            get { return secondaryArcana; }
            set
            {
                secondaryArcana = value;
                OnPropertyChanged("SecondaryArcana");
            }
        }

        private int secondaryRating;
        public int SecondaryRating
        {
            get { return secondaryRating; }
            set
            {
                secondaryRating = value;
                OnPropertyChanged("SecondaryRating");
            }
        }

        private string tertiaryValue;
        public string TertiaryValue
        {
            get { return tertiaryValue; }
            set
            {
                tertiaryValue = value;
                OnPropertyChanged("TertiaryValue");
            }
        }

        private int tertiaryRating;
        public int TertiaryRating
        {
            get { return tertiaryRating; }
            set
            {
                tertiaryRating = value;
                OnPropertyChanged("TertiaryRating");
            }
        }

        private int highestRating;
        public int HighestRating
        {
            get { return highestRating; }
            set
            {
                highestRating = value;
                OnPropertyChanged("HighestRating");
            }
        }
        #endregion

        private int spellFactors;
        public int SpellFactors
        {
            get { return spellFactors; }
            set
            {
                spellFactors = value;
                OnPropertyChanged("SpellFactors");
            }
        }

        private int potencyRating = 1;
        public int PotencyRating
        {
            get { return potencyRating; }
            set
            {
                potencyRating = value;
                OnPropertyChanged("Potency");
            }
        }

        private int durationRating = 1;
        public int DurationRating
        {
            get { return durationRating; }
            set
            {
                durationRating = value;
                OnPropertyChanged("Duration");
            }
        }

        #region Reach

        private int baseReach;
        public int BaseReach
        {
            get { return baseReach; }
            set
            {
                baseReach = value;
                OnPropertyChanged("BaseReach");
            }
        }

        private int reach;
        public int Reach
        {
            get { return reach; }
            set
            {
                reach = value;
                OnPropertyChanged("Reach");
            }
        }

        private int spentReach;
        public int SpentReach
        {
            get { return spentReach; }
            set
            {
                spentReach = value;
                OnPropertyChanged("SpentReach");
            }
        }

        #endregion

        private int dicePool = 1;
        public int DicePool
        {
            get { return dicePool; }
            set
            {
                dicePool = value;
                OnPropertyChanged("DicePool");
            }
        }

        public int CastingTime { get; set; }
        public int Range { get; set; }
        public int Potency { get; set; }
        #endregion

        #region Private Methods
        private void getArcana()
        {
            Arcana.Add(string.Empty);
            foreach (Spell item in Spells)
            {
                if (!Arcana.Contains(item.Arcana))
                {
                    Arcana.Add(item.Arcana);
                }
            }
        }
        #endregion

        #region Public Methods
        public void GetAvailableSpells()
        {
            AvailableSpells.Clear();

            var pSpells = from s in Spells
                         where s.Arcana == PrimaryArcana && s.Level <= PrimaryRating
                         select s;
            foreach (Spell spell in pSpells)
            {
                if (!AvailableSpells.Contains(spell))
                {
                    AvailableSpells.Add(spell);
                }
            }

            var sSpells = from s in Spells
                          where s.Arcana == SecondaryArcana && s.Level <= SecondaryRating
                          select s;
            foreach (Spell spell in sSpells)
            {
                if (!AvailableSpells.Contains(spell))
                {
                    AvailableSpells.Add(spell);
                }
            }

            var tSpells = from s in Spells
                          where s.Arcana == TertiaryValue && s.Level <= TertiaryRating
                          select s;
            foreach (Spell spell in tSpells)
            {
                if (!AvailableSpells.Contains(spell))
                {
                    AvailableSpells.Add(spell);
                }
            }
        }

        public void GetSpellStats()
        {
            HighestRating = Math.Max(PrimaryRating, Math.Max(SecondaryRating, TertiaryRating));

            if (SelectedSpell != null)
            {
                BaseReach = HighestRating - SelectedSpell.Level + 1 ;
                SpellFactors = PrimaryRating - 1;
                GetReach();
            }
        }

        #region Get Reach

        public void GetReach()
        {
            SpentReach = 0;
            Reach = 0;
            SpentReach = CastingTime + Range + Potency;
            Reach = BaseReach - SpentReach;
        }

        public void GetCastingTime(string name)
        {
            if (name == "Instant")
            {
                CastingTime = 1;
            }
            else
            {
                CastingTime = 0;
            }
            GetReach();
        }

        public void GetRange(string name)
        {
            if (name == "Sensory")
            {
                Range = 1;
            }
            else
            {
                Range = 0;
            }
            GetReach();
        }

        public void GetPotency(string name)
        {
            if (name.Contains("Advanced"))
            {
                Potency = 1;
            }
            else
            {
                Potency = 0;
            }
            GetReach();
        }
        #endregion

        #region Get Dice Pool
        public void GetDicePool()
        {
            HighestRating = Math.Max(PrimaryRating, Math.Max(SecondaryRating, TertiaryRating));
            DicePool = 0;

            int spentFocus = ((PotencyRating - 1) + (DurationRating - 1) - BaseReach) * 2;
            if (spentFocus < 0)
            {
                spentFocus = 0;
            }

            DicePool = Gnosis + HighestRating - spentFocus;
        }
        #endregion
        #endregion
    }
}
