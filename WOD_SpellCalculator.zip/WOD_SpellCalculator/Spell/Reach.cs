﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spell
{
    public class Reach
    {
        private int reachID;

        public int ReachID
        {
            get { return reachID; }
            set { reachID = value; }
        }

        private int spellFK;

        public int SpellFK
        {
            get { return spellFK; }
            set { spellFK = value; }
        }

        private int reachCost;

        public int ReachCost
        {
            get { return reachCost; }
            set { reachCost = value; }
        }

        private int manaCost;

        public int ManaCost
        {
            get { return manaCost; }
            set { manaCost = value; }
        }

        private string description;

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

    }
}
